Fixes # (id of the issue to be closed)

Changes proposed in this pull request:
- 

Test rendering with links to the example places:

Before

After
